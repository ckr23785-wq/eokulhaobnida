# 억울하옵니다 앱 (Android 빌드 안내)

1. make_apk.bat 더블클릭 → APK 자동 생성
2. Codemagic.io 업로드 → 자동 빌드
